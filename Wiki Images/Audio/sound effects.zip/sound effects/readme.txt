audios con nombres originales. los he clasificado como ves. 
tiene un sentido los nombres. por lo que he visto la primero lectra es algun diminutivo, como "i" de ingeniero o "u" para ui element.
segudio de otro nombre a veces reconocible, y luego numeros o letras para indicar las partes.
si algo en particular te intersa, y quieres todos los audios solo poner una parte del nombre en el buscador y te saldran todos los relacionados.
la clasificacion hecha es para usarlos segun el estilo que tienen.
de resto si quieres el zip con los archivos originales, estara en el drive que cada lead tiene acceso